CREATE TABLE IF NOT EXISTS `opset` (
  `opset_id` int(11) NOT NULL AUTO_INCREMENT,
  `opset_name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`opset_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
